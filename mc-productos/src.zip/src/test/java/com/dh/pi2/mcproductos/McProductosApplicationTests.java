package com.dh.pi2.mcproductos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class McProductosApplicationTests {

	@Test
	void contextLoads() {
	}

}
